const semanticClassNames = {
  root: 'column-strip',
  column: 'column-strip__column',
} as const;

export default semanticClassNames;
