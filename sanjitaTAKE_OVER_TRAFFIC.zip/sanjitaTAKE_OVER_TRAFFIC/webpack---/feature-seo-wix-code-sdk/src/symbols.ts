export const name = 'seoWixCodeSdk' as const
export const namespace = 'seo' as const
