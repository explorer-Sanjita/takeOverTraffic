export const name = 'windowMessageRegistrar' as const
export const WindowMessageRegistrarSymbol = Symbol('WindowMessageRegistrar')
