import { initLazyCustomElements } from './wixLazyCustomElementRegistry'

initLazyCustomElements()
