export const name = 'componentsQaApi' as const
