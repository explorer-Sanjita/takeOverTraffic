export const name = 'coBranding' as const
