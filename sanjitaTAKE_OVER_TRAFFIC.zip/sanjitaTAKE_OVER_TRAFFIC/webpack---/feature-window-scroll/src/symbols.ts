export const name = 'windowScroll' as const
export const WindowScrollApiSymbol = Symbol('windowScrollApi')
export const ResolvableReadyForScrollPromiseSymbol = Symbol('ResolvableWindowScrollPromise')
