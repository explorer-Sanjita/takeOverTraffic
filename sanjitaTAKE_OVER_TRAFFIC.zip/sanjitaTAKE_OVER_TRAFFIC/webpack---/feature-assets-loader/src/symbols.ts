export const name = 'assetsLoader' as const

export const PageStyleLoaderSymbol = Symbol('PageStyleLoader')
