import ContainerSdk from '@wix/thunderbolt-elements/src/components/Container/corvid/Container.corvid';


const Container = {
  sdk: ContainerSdk
};


export const components = {
  ['Container']: Container
};

