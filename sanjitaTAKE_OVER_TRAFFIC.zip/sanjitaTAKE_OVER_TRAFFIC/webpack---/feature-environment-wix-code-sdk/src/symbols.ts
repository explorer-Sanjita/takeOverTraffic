export const name = 'environmentWixCodeSdk' as const
export const namespace = 'environment' as const
