export const name = 'presenceApi' as const

export const PresenceApiSymbol = Symbol('PresenceApiSymbol')
