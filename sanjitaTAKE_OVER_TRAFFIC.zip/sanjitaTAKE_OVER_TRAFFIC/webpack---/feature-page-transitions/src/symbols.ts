export const PageTransitionsSymbol = Symbol('PageTransitions')
export const PageTransitionsCompletedSymbol = Symbol('PageTransitionsCompleted')
export const name = 'pageTransitions' as const
