export const rendererTypeQueryParam = 'wix-renderer-type'
